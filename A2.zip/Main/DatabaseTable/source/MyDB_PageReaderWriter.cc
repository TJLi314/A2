
#ifndef PAGE_RW_C
#define PAGE_RW_C

#include "MyDB_PageReaderWriter.h"
#include <memory>

MyDB_PageReaderWriter :: MyDB_PageReaderWriter (int pageSize, MyDB_BufferManagerPtr mgr, MyDB_TablePtr table, int index, bool isNewPage) {
    this->pageSize = pageSize;
    this->handle = mgr->getPage(table, index);
    if (isNewPage) {
        this->clear();
    }
}

MyDB_PageReaderWriter :: MyDB_PageReaderWriter () {
    this->pageSize = 0;
    this->handle = nullptr;
}

void MyDB_PageReaderWriter :: clear () {
    PageHeader * header = (PageHeader *)handle->getBytes();
    memset(header, 0, pageSize);
    header->type = RegularPage;
    handle->wroteBytes();
}

MyDB_PageType MyDB_PageReaderWriter :: getType () {
	return ((PageHeader *)handle->getBytes())->type;
}

MyDB_RecordIteratorPtr MyDB_PageReaderWriter :: getIterator (MyDB_RecordPtr ptr) {
    void * header = handle->getBytes();
	MyDB_PageRecIteratorPtr itr =  std::make_shared<MyDB_PageRecIterator>(ptr, this->handle, sizeof(PageHeader));
	return itr;
}

void MyDB_PageReaderWriter :: setType (MyDB_PageType type) {
    void * buf = (PageHeader *)handle->getBytes();
    ((PageHeader *)buf)->type = type;
    handle->wroteBytes();
}

bool MyDB_PageReaderWriter :: append (MyDB_RecordPtr rec) {
    PageHeader * header = (PageHeader *)handle->getBytes();
    if (header->constructed == 0) {
        header->pageSize = pageSize;
        header->nextFreeByte = sizeof(PageHeader);
        header->constructed = 1;
        handle->wroteBytes();
    }

    if (header->nextFreeByte + rec->getBinarySize() > header->pageSize) {
        return false;
    }

    void * toWrite = (char *)header + header->nextFreeByte;
    rec->toBinary(toWrite);
    header->nextFreeByte = header->nextFreeByte + rec->getBinarySize();
    handle->wroteBytes();
    return true;
}

MyDB_PageReaderWriter :: ~MyDB_PageReaderWriter () {
}

#endif
